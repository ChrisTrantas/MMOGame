Can you last in the dark?

CONTROLS:
-UP, accelerate
-LEFt/RIGHT, steer
-DOWN, teleport
-SPACEBAR, shoot
-EQUAL SIGN, toggle the darkness (DO NOT HOLD DOWN IF EPILEPTIC)